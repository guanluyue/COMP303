public enum Direction {
    TAKEOFF, LAND, UP, DOWN, FORWARD, BACKWARDS, FOCUS, CAPTURE
}


