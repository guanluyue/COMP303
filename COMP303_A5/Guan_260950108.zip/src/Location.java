/*
Fixed event locations
 */
public enum Location {
    BellCentre, OlympicStadium, ParcJeanDrapeau, PlaceDesArts, Multiple, Unknown;
}
