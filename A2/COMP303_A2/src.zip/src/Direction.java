public enum Direction {
    FORWARD, BACKWARD, LEFT, RIGHT, UP, DOWN;
}
