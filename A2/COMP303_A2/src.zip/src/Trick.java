public enum Trick {
    TAKEOFF, PUCKER, SIDEWINDER;
}
