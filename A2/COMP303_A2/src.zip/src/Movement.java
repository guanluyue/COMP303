public interface Movement {
    /**
     * Execute a drone movement
     */
    void execute();
}
